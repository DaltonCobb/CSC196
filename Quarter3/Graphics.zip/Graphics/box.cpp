#include "box.h"

void Box::Update(float dt)
{
}

void Box::Draw(Core::Graphics& graphics)
{
}
