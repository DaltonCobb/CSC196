#include "line.h"

void Line::Update(float dt)
{
}

void Line::Draw(Core::Graphics& graphics)
{
}
