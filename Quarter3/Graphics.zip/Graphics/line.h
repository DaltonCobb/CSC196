#pragma once
#include "shape.h"

class Line : public Shape
{
public:
	Line() {}

	virtual void Update(float dt) override;
	virtual void Draw(Core::Graphics& graphics) override;
};

