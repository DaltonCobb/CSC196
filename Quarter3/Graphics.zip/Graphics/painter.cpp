#include "painter.h"
#include "MathLib.h"

std::vector<nc::vector2> points;
float timer = 0;

void Painter::Update(float dt)
{
    int x, y;
    Core::Input::GetMousePos(x, y);
    nc::vector2 point{ x, y };

    timer = timer + dt;
    if (timer >= 0.05f)
    {
        timer = 0;
        points.push_back(point);
    }
}

void Painter::Draw(Core::Graphics& graphics)
{
    if (!points.empty())
    {
        for (size_t i = 0; i < points.size() - 1; i++)
        {
            graphics.DrawLine(points[i].x, points[i].y, points[i + 1].x, points[i + 1].y);
        }
    }
}
