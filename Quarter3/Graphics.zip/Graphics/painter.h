#pragma once
#include "core.h"
#include "shape.h"
#include <vector>

class Painter
{
public:
	Painter() {}
	~Painter() {}

	void Update(float dt);
	void Draw(Core::Graphics& graphics);

private:
	std::vector<Shape*> m_shapes;
};
