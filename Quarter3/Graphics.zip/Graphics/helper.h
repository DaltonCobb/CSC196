#pragma once



//class C
//{
//public:
//	C() {}
//
//	inline int GetValue() { return m_value; }
//};
