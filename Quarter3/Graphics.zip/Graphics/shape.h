#pragma once
#include "core.h"

class Shape
{
public:
	Shape() {}

	virtual void Update(float dt) = 0;
	virtual void Draw(Core::Graphics& graphics) = 0;
};


