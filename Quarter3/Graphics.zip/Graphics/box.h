#pragma once
#include "shape.h"

class Box :	public Shape
{

public:
	virtual void Update(float dt) override;
	virtual void Draw(Core::Graphics& graphics) override;
};

