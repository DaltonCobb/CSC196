// MathLib.cpp : Defines the functions for the static library.
//

#include "framework.h"
#include "MathLib.h"

float sqr(float value)
{
	return value * value;
}
